package za.ac.cput.domain;


public class Password {
    private final int passwordId;
    private String oldPassword;
    private final String newPassword;

    private Password(Builder builder) {
        this.passwordId  = builder.passwordId;
        this.oldPassword = builder.oldPassword;
        this.newPassword = builder.newPassword;
    }

    public void updatePassword() {
        if (!verifyPassword())
            throw new SecurityException("Old password verification failed.");
        this.oldPassword = newPassword;
        System.out.println("[Password] Password updated (id=" + passwordId + ").");
    }

    public boolean verifyPassword() {
        boolean ok = oldPassword != null && !oldPassword.isBlank();
        System.out.println("[Password] Verification " + (ok ? "passed." : "FAILED."));
        return ok;
    }

    public int getPasswordId() { return passwordId; }
    public String getOldPassword() { return oldPassword; }
    public String getNewPassword() { return newPassword; }

    @Override
    public String toString() { return "Password{id=" + passwordId + "}"; }

    public static final class Builder {
        private final int passwordId;
        private final String oldPassword;
        private final String newPassword;

        public Builder(int passwordId, String oldPassword, String newPassword) {
            if (oldPassword == null || oldPassword.isBlank())
                throw new IllegalArgumentException("Old password is required.");
            if (newPassword == null || newPassword.isBlank())
                throw new IllegalArgumentException("New password is required.");
            this.passwordId = passwordId;
            this.oldPassword = oldPassword;
            this.newPassword = newPassword;
        }

        public Password build() { return new Password(this); }
    }
}