package za.ac.cput.domain;

public class Profile {
    private final int profileId;
    private final int userId;
    private String bio;
    private String contactInfo;

    private Profile(Builder builder) {
        this.profileId = builder.profileId;
        this.userId = builder.userId;
        this.bio = builder.bio;
        this.contactInfo = builder.contactInfo;
    }

    public void viewProfile() {
        System.out.println("[Profile] userId=" + userId);
        System.out.println("Bio: " + bio);
        System.out.println("Contact Info: " + contactInfo);
    }

    public void editProfile(String newBio, String newContactInfo) {
        this.bio = newBio;
        this.contactInfo = newContactInfo;
        System.out.println("[Profile] Profile updated for userId=" + userId + ".");
    }

    public int getProfileId() { return profileId; }
    public int getUserId() { return userId; }
    public String getBio() { return bio; }
    public void   setBio(String b) { this.bio = b; }
    public String getContactInfo() { return contactInfo; }
    public void   setContactInfo(String c) { this.contactInfo = c; }

    @Override
    public String toString() {
        return "Profile{profileId=" + profileId + ", userId=" + userId + "}";
    }

    public static final class Builder {
        private final int profileId;
        private final int userId;
        private String bio = "";
        private String contactInfo = "";

        public Builder(int profileId, int userId) {
            this.profileId = profileId;
            this.userId = userId;
        }

        public Builder bio(String bio) { this.bio = bio; return this; }
        public Builder contactInfo(String contact) { this.contactInfo = contact; return this; }

        public Profile build() { return new Profile(this); }
    }
}
