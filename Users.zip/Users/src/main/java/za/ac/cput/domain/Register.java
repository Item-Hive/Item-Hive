package za.ac.cput.domain;

public class Register {
    private final int registrationId;
    private final String username;
    private final String email;

    private Register(Builder b) {
        this.registrationId = b.registrationId;
        this.username = b.username;
        this.email = b.email;
    }

    public User createAccount(String password) {
        if (!validateInput())
            throw new IllegalArgumentException("Invalid registration input.");
        System.out.println("[Register] Account created for username='" + username + "'.");
        return new User.Builder(registrationId, username)
                .email(email)
                .password(password)
                .build();
    }

    public boolean validateInput() {
        boolean valid = username != null && !username.isBlank()
                && email    != null && email.contains("@");
        System.out.println("[Register] Validation " + (valid ? "passed." : "FAILED."));
        return valid;
    }

    public int getRegistrationId() { return registrationId; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return "Register{id=" + registrationId + ", username='" + username + "', email='" + email + "'}";
    }

    public static final class Builder {
        private final int    registrationId;
        private final String username;
        private String email = "";

        public Builder(int registrationId, String username) {
            if (username == null || username.isBlank())
                throw new IllegalArgumentException("Username is required.");
            this.registrationId = registrationId;
            this.username = username;
        }

        public Builder email(String email) { this.email = email; return this; }

        public Register build() { return new Register(this); }
    }
}
