package za.ac.cput.domain;

public class SignOut {
    private final int sessionId;
    private final int userId;

    private SignOut(Builder b) {
        this.sessionId = b.sessionId;
        this.userId = b.userId;
    }

    public void endSession() {
        System.out.println("[SignOut] Session #" + sessionId
                + " terminated for userId=" + userId + ".");
    }

    public int getSessionId() { return sessionId; }
    public int getUserId() { return userId; }

    @Override
    public String toString() {
        return "SignOut{sessionId=" + sessionId + ", userId=" + userId + "}";
    }

    public static final class Builder {
        private final int sessionId;
        private final int userId;

        public Builder(int sessionId, int userId) {
            this.sessionId = sessionId;
            this.userId = userId;
        }

        public SignOut build() { return new SignOut(this); }
    }
}
