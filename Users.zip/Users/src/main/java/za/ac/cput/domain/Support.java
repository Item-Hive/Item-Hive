package za.ac.cput.domain;

public class Support {
    private final int ticketId;
    private final int userId;
    private final String issueDescription;
    private String status;

    private Support(Builder b) {
        this.ticketId = b.ticketId;
        this.userId = b.userId;
        this.issueDescription = b.issueDescription;
        this.status = b.status;
    }

    public void createTicket() {
        this.status = "OPEN";
        System.out.println("[Support] Ticket #" + ticketId
                + " opened for userId=" + userId + " | " + issueDescription);
    }

    public void respondToTicket(String response) {
        this.status = "IN_PROGRESS";
        System.out.println("[Support] Ticket #" + ticketId
                + " response: " + response + " | Status -> " + status);
    }

    public int getTicketId() { return ticketId; }
    public int getUserId() { return userId; }
    public String getIssueDescription() { return issueDescription; }
    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }

    @Override
    public String toString() {
        return "Support{ticketId=" + ticketId + ", userId=" + userId
                + ", status='" + status + "'}";
    }

    public static final class Builder {

        private final int ticketId;
        private final int userId;
        private final String issueDescription;

        private String status = "OPEN";

        public Builder(int ticketId, int userId, String issueDescription) {
            if (issueDescription == null || issueDescription.isBlank())
                throw new IllegalArgumentException("Issue description is required.");
            this.ticketId = ticketId;
            this.userId = userId;
            this.issueDescription = issueDescription;
        }

        public Builder status(String status) { this.status = status; return this; }

        public Support build() { return new Support(this); }
    }
}
