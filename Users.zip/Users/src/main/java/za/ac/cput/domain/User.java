package za.ac.cput.domain;

public class User {
    private final int userId;
    private String name;
    private String email;
    private String password;

    private User(Builder builder) {
        this.userId = builder.userId;
        this.name = builder.name;
        this.email = builder.email;
        this.password = builder.password;
    }

    public void login() { System.out.println("[User] " + name + " logged in."); }
    public void logout() { System.out.println("[User] " + name + " logged out."); }

    public void resetPassword(String newPassword) {
        this.password = newPassword;
        System.out.println("[User] Password reset for " + name + ".");
    }

    public int getUserId() { return userId; }
    public String getName() { return name; }
    public void setName(String n) { this.name = n; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public String getPassword() { return password; }
    public void setPassword(String p) { this.password = p; }

    @Override
    public String toString() {
        return "User{id=" + userId + ", name='" + name + "', email='" + email + "'}";
    }

    public static final class Builder {

        private final int userId;
        private final String name;

        private String email = "";
        private String password = "";

        public Builder(int userId, String name) {
            if (name == null || name.isBlank())
                throw new IllegalArgumentException("User name is required.");
            this.userId = userId;
            this.name = name;
        }

        public Builder email(String email) { this.email = email; return this; }
        public Builder password(String password) { this.password = password; return this; }

        public User build() { return new User(this); }
    }
}
