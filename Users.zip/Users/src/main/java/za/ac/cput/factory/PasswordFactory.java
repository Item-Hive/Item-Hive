package za.ac.cput.factory;

import za.ac.cput.domain.Password;

public final class PasswordFactory {

    private static int nextId = 1;

    private PasswordFactory() {}

    public static Password create(String oldPassword, String newPassword) {
        return new Password.Builder(nextId++, oldPassword, newPassword).build();
    }

    public static Password create(int id, String oldPassword, String newPassword) {
        return new Password.Builder(id, oldPassword, newPassword).build();
    }
}