package za.ac.cput.factory;

import za.ac.cput.domain.Profile;

public final class ProfileFactory {

    private static int nextId = 1;

    private ProfileFactory() {}

    public static Profile createBlank(int userId) {
        return new Profile.Builder(nextId++, userId).build();
    }

    public static Profile create(int userId, String bio) {
        return new Profile.Builder(nextId++, userId)
                .bio(bio)
                .build();
    }

    public static Profile create(int userId, String bio, String contactInfo) {
        return new Profile.Builder(nextId++, userId)
                .bio(bio)
                .contactInfo(contactInfo)
                .build();
    }

    public static Profile create(int id, int userId, String bio, String contactInfo) {
        return new Profile.Builder(id, userId)
                .bio(bio)
                .contactInfo(contactInfo)
                .build();
    }
}