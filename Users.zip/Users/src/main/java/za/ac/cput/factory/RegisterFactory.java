package za.ac.cput.factory;

import za.ac.cput.domain.Register;

public final class RegisterFactory {

    private static int nextId = 1;

    private RegisterFactory() {}

    public static Register create(String username) {
        return new Register.Builder(nextId++, username).build();
    }

    public static Register create(String username, String email) {
        return new Register.Builder(nextId++, username)
                .email(email)
                .build();
    }

    public static Register create(int id, String username, String email) {
        return new Register.Builder(id, username)
                .email(email)
                .build();
    }
}