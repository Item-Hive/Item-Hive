package za.ac.cput.factory;

import za.ac.cput.domain.SignOut;

public final class SignOutFactory {

    private static int nextId = 1;

    private SignOutFactory() {}

    public static SignOut create(int userId) {
        return new SignOut.Builder(nextId++, userId).build();
    }

    public static SignOut create(int sessionId, int userId) {
        return new SignOut.Builder(sessionId, userId).build();
    }
}