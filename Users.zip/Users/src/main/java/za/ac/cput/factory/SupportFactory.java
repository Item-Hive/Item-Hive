package za.ac.cput.factory;

import za.ac.cput.domain.Support;

public final class SupportFactory {

    private static int nextId = 1;

    private SupportFactory() {}

    public static Support create(int userId, String issueDescription) {
        Support ticket = new Support.Builder(nextId++, userId, issueDescription)
                .status("OPEN")
                .build();
        ticket.createTicket();
        return ticket;
    }

    public static Support create(int id, int userId, String issueDescription, String status) {
        return new Support.Builder(id, userId, issueDescription)
                .status(status)
                .build();
    }
}