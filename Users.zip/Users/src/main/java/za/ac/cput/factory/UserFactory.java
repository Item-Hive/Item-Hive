package za.ac.cput.factory;


import za.ac.cput.domain.User;

public final class UserFactory {

    private static int nextId = 1;

    private UserFactory() {}

    //public static User create(String name) {
      //  return new User.Builder(nextId++, name).build();
    //}

    public static User create(String name, String email, String password) {
        return new User.Builder(nextId++, name)
                .email(email)
                .password(password)
                .build();
    }

    public static User create(int id, String name, String email, String password) {
        return new User.Builder(id, name)
                .email(email)
                .password(password)
                .build();
    }
}

