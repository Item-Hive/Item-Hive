package za.ac.cput.main;

import za.ac.cput.domain.*;
import za.ac.cput.factory.*;
import za.ac.cput.repository.ProfileRepository;
import za.ac.cput.repository.SupportRepository;
import za.ac.cput.repository.UserRepository;

public class Main {

    public static void main(String[] args) {

        UserRepository userRepo = new UserRepository();
        ProfileRepository profileRepo = new ProfileRepository();
        SupportRepository supportRepo = new SupportRepository();

        separator("1. REGISTER A NEW USER");

        Register reg  = RegisterFactory.create("Soso", "sosonkomo@gmail.com");
        User user = reg.createAccount("@Password");
        userRepo.save(user);

        separator("2. USER LOGIN");

        user.login();

        separator("3. UPDATE PASSWORD");

        Password pwd = PasswordFactory.create("@Password", "Pass_word");
        pwd.updatePassword();
        user.resetPassword(pwd.getNewPassword());
        userRepo.update(user);

        separator("4. PROFILE – CREATE & EDIT");

        Profile profile = ProfileFactory.create(
                user.getUserId(),
                "Women in tech, Software developer.",
                "sosonkomo@gmail.com | +27 76 256 4642");
        profileRepo.save(profile);
        profile.viewProfile();

        profile.editProfile(
                "Senior software developer & Cybersecurity.",
                "sosonkom@gmail.com | +27 66 541 4307");
        profileRepo.update(profile);
        profile.viewProfile();

        separator("5. SUPPORT TICKETS");

        Support ticket1 = SupportFactory.create(user.getUserId(),
                "Cannot reset password via email link.");
        Support ticket2 = SupportFactory.create(user.getUserId(),
                "Profile photo upload fails on mobile.");
        supportRepo.save(ticket1);
        supportRepo.save(ticket2);

        ticket1.respondToTicket("Escalated to the auth team.");
        supportRepo.update(ticket1);

        System.out.println("\nAll tickets for userId=" + user.getUserId() + ":");
        supportRepo.findByUserId(user.getUserId())
                .forEach(t -> System.out.println("  " + t));

        separator("6. SIGN OUT");

        SignOut signOut = SignOutFactory.create(user.getUserId());
        signOut.endSession();
        user.logout();

        separator("7. REPOSITORY QUERIES");

        System.out.println("All users: " + userRepo.findAll());
        System.out.println("Find user 1: " + userRepo.findById(1).orElse(null));
        System.out.println("By email: " + userRepo.findByEmail("sosonkomo@gmail.com").orElse(null));
        System.out.println("Open tickets: " + supportRepo.findByStatus("OPEN"));

        separator("8. DELETE USER");

        userRepo.deleteById(user.getUserId());
        System.out.println("Users after deletion: " + userRepo.findAll());
    }

    private static void separator(String title) {
        System.out.println("\n" + "─".repeat(58));
        System.out.println("  " + title);
        System.out.println("─".repeat(58));
    }
}