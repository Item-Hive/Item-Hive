package za.ac.cput.repository;

import za.ac.cput.domain.Profile;

import java.util.*;

public class ProfileRepository implements IRepository<Profile, Integer> {

    private final Map<Integer, Profile> store = new LinkedHashMap<>();

    @Override
    public void save(Profile profile) {
        store.put(profile.getProfileId(), profile);
        System.out.println("[ProfileRepository] Saved " + profile);
    }

    @Override
    public Optional<Profile> findById(Integer id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<Profile> findAll() { return new ArrayList<>(store.values()); }

    @Override
    public void update(Profile profile) {
        if (!store.containsKey(profile.getProfileId()))
            throw new NoSuchElementException("Profile id=" + profile.getProfileId() + " not found.");
        store.put(profile.getProfileId(), profile);
        System.out.println("[ProfileRepository] Updated " + profile);
    }

    @Override
    public void deleteById(Integer id) {
        store.remove(id);
        System.out.println("[ProfileRepository] Deleted profileId=" + id);
    }

    public Optional<Profile> findByUserId(int userId) {
        return store.values().stream()
                .filter(p -> p.getUserId() == userId)
                .findFirst();
    }
}
