package za.ac.cput.repository;

import za.ac.cput.domain.Support;
import java.util.*;
import java.util.stream.Collectors;

public class SupportRepository implements IRepository<Support, Integer> {

    private final Map<Integer, Support> store = new LinkedHashMap<>();

    @Override
    public void save(Support ticket) {
        store.put(ticket.getTicketId(), ticket);
        System.out.println("[SupportRepository] Saved " + ticket);
    }

    @Override
    public Optional<Support> findById(Integer id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<Support> findAll() { return new ArrayList<>(store.values()); }

    @Override
    public void update(Support ticket) {
        if (!store.containsKey(ticket.getTicketId()))
            throw new NoSuchElementException("Ticket id=" + ticket.getTicketId() + " not found.");
        store.put(ticket.getTicketId(), ticket);
        System.out.println("[SupportRepository] Updated " + ticket);
    }

    @Override
    public void deleteById(Integer id) {
        store.remove(id);
        System.out.println("[SupportRepository] Deleted ticketId=" + id);
    }

    public List<Support> findByUserId(int userId) {
        return store.values().stream()
                .filter(t -> t.getUserId() == userId)
                .collect(Collectors.toList());
    }

    public List<Support> findByStatus(String status) {
        return store.values().stream()
                .filter(t -> t.getStatus().equalsIgnoreCase(status))
                .collect(Collectors.toList());
    }
}
