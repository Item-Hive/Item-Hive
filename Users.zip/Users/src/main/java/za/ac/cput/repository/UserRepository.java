package za.ac.cput.repository;

// BUG FIXED 1: Was implementing `JpaRepository` which does not exist in this project.
//              Changed to `IRepository<User, Integer>` — the correct project interface.
// BUG FIXED 2: Missing imports for `User` and `IRepository` added.
import za.ac.cput.domain.User;

import java.util.*;

public class UserRepository implements IRepository<User, Integer> {

    private final Map<Integer, User> store = new LinkedHashMap<>();

    @Override
    public void save(User user) {
        if (store.containsKey(user.getUserId()))
            throw new IllegalArgumentException("User id=" + user.getUserId() + " already exists.");
        store.put(user.getUserId(), user);
        System.out.println("[UserRepository] Saved " + user);
    }

    @Override
    public Optional<User> findById(Integer id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<User> findAll() { return new ArrayList<>(store.values()); }

    @Override
    public void update(User user) {
        if (!store.containsKey(user.getUserId()))
            throw new NoSuchElementException("User id=" + user.getUserId() + " not found.");
        store.put(user.getUserId(), user);
        System.out.println("[UserRepository] Updated " + user);
    }

    @Override
    public void deleteById(Integer id) {
        if (store.remove(id) == null)
            throw new NoSuchElementException("User id=" + id + " not found.");
        System.out.println("[UserRepository] Deleted userId=" + id);
    }

    public Optional<User> findByEmail(String email) {
        return store.values().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }
}